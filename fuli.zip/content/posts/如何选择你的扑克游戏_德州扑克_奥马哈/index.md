---
title: '如何选择你的扑克游戏_德州扑克_奥马哈'
date: 2025-01-11
draft: true
author: Phil Galfond
---
<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
  <iframe src="https://www.youtube.com/embed/BdAT97dxFfk" 
          style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;"
          allowfullscreen title="YouTube Video">
  </iframe>
</div>
